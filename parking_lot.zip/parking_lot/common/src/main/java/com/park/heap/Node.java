package com.park.heap;

public class Node
{
	private int id;
	private int distance;

	public Node(int id,int distance)
	{
		this.id=id;
		this.distance=distance;
	}

	public void setId(int id)
	{
		this.id=id;
	}
	public int getId()
	{
		return this.id;
	}

	public void setDistance(int distance)
	{
		this.distance=distance;
	}

	public int getDistance()
	{
		return this.distance;
	}
}