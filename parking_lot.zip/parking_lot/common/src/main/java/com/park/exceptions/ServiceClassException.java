package com.park.exceptions;

public class ServiceClassException extends Exception{
	public ServiceClassException(String message)
	{
		super(message);
	}
	public ServiceClassException(String message,Throwable error)
	{
		super(message,error);
	}
}