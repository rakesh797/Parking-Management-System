package com.park.heap;
import java.util.ArrayList;
import com.park.heap.Node;

public class MinHeap {

    public static ArrayList<Node> list;

    public MinHeap() {

        this.list = new ArrayList<Node>();
    }

    public MinHeap(ArrayList<Node> nodes) {

        this.list = nodes;
        buildHeap();
    }

    public void insert(Node node) {

        list.add(node);
        int i = list.size() - 1;
        int parent = parent(i);

        while (parent != i && list.get(i).getDistance() < list.get(parent).getDistance()) {

            swap(i, parent);
            i = parent;
            parent = parent(i);
        }
    }

    public void buildHeap() {

        for (int i = list.size() / 2; i >= 0; i--) {
            minHeapify(i);
        }
    }

    public Node extractMin() {

        if (list.size() == 0) {

            throw new IllegalStateException("MinHeap is EMPTY");
        } else if (list.size() == 1) {

            Node min = list.remove(0);
            return min;
        }

        Node min = list.get(0);
        Node lastItem = list.remove(list.size() - 1);
        list.set(0, lastItem);

        minHeapify(0);

        return min;
    }

    public void decreaseKey(int i, Node node) {

        if (list.get(i).getDistance() < node.getDistance()) {

            throw new IllegalArgumentException("Key is larger than the original key");
        }

        list.set(i, node);
        int parent = parent(i);

       
        while (i > 0 && list.get(parent).getDistance() > list.get(i).getDistance()) {

            swap(i, parent);
            i = parent;
            parent = parent(parent);
        }
    }

    private void minHeapify(int i) {

        int left = left(i);
        int right = right(i);
        int smallest = -1;

        
        if (left <= list.size() - 1 && list.get(left).getDistance() < list.get(i).getDistance()) {
            smallest = left;
        } else {
            smallest = i;
        }

        if (right <= list.size() - 1 && list.get(right).getDistance() < list.get(smallest).getDistance()) {
            smallest = right;
        }

        
        if (smallest != i) {

            swap(i, smallest);
            minHeapify(smallest);
        }
    }

    public Node getMin() {

        return list.get(0);
    }

    public boolean isEmpty() {

        return list.size() == 0;
    }

    private int right(int i) {

        return 2 * i + 2;
    }

    private int left(int i) {

        return 2 * i + 1;
    }

    private int parent(int i) {

        return (i - 1) / 2;
    }

    private void swap(int i, int parent) {

        Node temp = list.get(parent);
        list.set(parent, list.get(i));
        list.set(i, temp);
    }

}