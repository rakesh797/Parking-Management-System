package com.park.enumerations;
import java.util.Map;
import java.util.HashMap;

public enum Color{
	GREEN("Green"),
	SILVER("Silver"),
	RED("Red"),
	WHITE("White"),
	GRAY("Gray"),
	YELLOW("Yellow"),
	ORANGE("Orange"),
	BLACK("Black");

	private static final Map<String, Color> BY_LABEL=new HashMap<>();
	public final String label;

	private Color(String label)
	{
		this.label=label;
	}

	// populating colors into map
	static {

		for(Color color:values()){
			BY_LABEL.put(color.label,color);
		}
	}

	public static Color valueOfLabel(String label){
		return BY_LABEL.get(label);
	}


}