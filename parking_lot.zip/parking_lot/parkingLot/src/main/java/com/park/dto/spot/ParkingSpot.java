package com.park.dto.spot;
import com.park.dto.car.Car;

public class ParkingSpot
{
	private int id;
	private int spotDistance;
	private int status;
	private long ticketNumber;	
	private Car car;	
	// some more properties

	public ParkingSpot()
	{
		this.id=0;
		this.ticketNumber=0;
		this.spotDistance=0;
		this.car=null;
		this.status=0;
	}


	public ParkingSpot(int id,int spotDistance,long ticketNumber,Car car,int status)
	{
		this.id=id;
		this.ticketNumber=ticketNumber;
		this.spotDistance=spotDistance;
		this.car=car;
		this.status=status;
	}

	public void setId(int id)
	{
		this.id=id;
	}

	public int getId()
	{
		return this.id;
	}

	public void setTicketNumber(long ticketNumber)
	{
		this.ticketNumber=ticketNumber;
	}
	public long getTicketNumber()
	{
		return this.ticketNumber;
	}

	public void setSpotDistance(int spotDistance)
	{
		this.spotDistance=spotDistance;
	}

	public int getSpotDistance()
	{
		return this.spotDistance;
	}

	public void setStatus(int status)
	{
		this.status=status;
	}
	public int getStatus()
	{
		return this.status;
	}

	public void setCar(Car car)
	{
		this.car=car;
	}
	public Car getCar()
	{
		return this.car;
	}

}