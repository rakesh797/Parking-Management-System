package com.park.main;
import com.park.model.ParkingLotModel;

public class Main{

	public static void main(String[] args)
	{
		ParkingLotModel model =new ParkingLotModel();
		model.execute(); 

	}
}