package com.park.model;
import java.util.Scanner;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.HashMap;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import com.park.view.MenuView;
import com.park.dto.spot.ParkingSpot;
import com.park.exceptions.ServiceClassException;
import com.park.services.ParkingLotServiceInterface;
import com.park.services.ParkingLotService;
import com.park.enumerations.Color;


public class ParkingLotModel
{
	private Scanner scan=new Scanner(System.in);
	ParkingLotServiceInterface parkingLotInterface=new ParkingLotService();
	List<String> colorNames=new ArrayList<String>();
	Map<Integer,String> colorMap=new HashMap<>();

	public ParkingLotModel() 
	{	
		
		this.populateDataStructures();
		MenuView.displayParkingLotHeading();		
	}

	public void populateDataStructures()
	{
		try
		{
			colorNames= Stream.of(Color.values()).map(Color::name).collect(Collectors.toList());
			for(int i=1;i<=colorNames.size();i++)
			{
				colorMap.put(i,colorNames.get(i));
			}
		}catch(Exception exception)
		{
			System.out.println(exception);
		}

	}
	public void execute()
	{
		
		this.loadMainMenu();
	}

	public void loadMainMenu() 
	{
		
		while(true)
		{

			MenuView.displayMainMenu();
			MenuView.displayLine(">> Enter your options : ");
			String str=scan.next();

			if(str.length()==1 && str.charAt(0)>='0' && str.charAt(0)<='2')
			{
				int input=Integer.parseInt(str);
				if(input>0)
				{
					switch(input)
					{
						case 1:						
							this.createNewParkingLot();
							break;
						case 2:
						    this.loadPreviousParkingLot();
						    break;
					}
				}else if(input==0)
					break;
					
				}	
				else
					MenuView.displayLine("!!! Please Enter the valid option !!!\n");
			}
	}
	public void createNewParkingLot() 
	{
		MenuView.displayNewParkingLotHeading();		
		MenuView.displayLine("Enter Parking Size : ");
		int parkingSize=scan.nextInt();
		if(parkingSize>0)
		{
			try
			{
					boolean result=parkingLotInterface.createNewParkingLot(parkingSize);
					if(result==true)
					{
						this.loadQueryOperations();
					}
					if(result==false)
					{
						MenuView.displayLine("!!! Something went wrong cannot create ParkingLot !!!\n");
					}

			}catch(ServiceClassException exception)
			{
				MenuView.displayLine("!!! Internal Error !!!\n");
			}
			}
			else{
				MenuView.displayLine("!!!Please Enter the valid option !!!\n");
			}
	}

	public void loadPreviousParkingLot(){
		try
		{
			boolean result=parkingLotInterface.loadExistingParkingLot();
			MenuView.displayLine("Previous Parking Lot is Loaded Successfully\n");
			if(result==true) this.loadQueryOperations();
			else MenuView.displayLine("!!! No Existing Data to load !!!\n");

		}catch(ServiceClassException exception)
		{
			MenuView.displayLine("!!! Internal Error !!!\n");
		}	
	}

	public void loadQueryOperations()
	{
		while(true)
		{
			MenuView.loadQueryMenu();
			MenuView.displayLine(">> Enter your options : ");
			String str=scan.next();

			if(str.length()==1 && str.charAt(0)>='0' && str.charAt(0)<='5')
			{
				int input=Integer.parseInt(str);

				if(input>0)
				{
					switch(input)
					{
						case 1:
							this.parkNewCarInParkingLot();
							break;
						case 2:
							this.departCarFromParkingLot();
						    
						    break;
						case 3:
							this.getRegistrationNumbersBasedOnColor();
							
						    break;
						case 4:
						    this.getTicketNumberBasedOnRegistrationNumber();
							
						    break;
						case 5:
						    this.getTicketNumbersBasedOnColor();
							
						    break;


					}
				}
				else if(input==0) break;
		}
			else MenuView.displayLine("!!! Please Enter the valid option !!!\n");
		}

	}

	public void parkNewCarInParkingLot()
	{
		try
		{
			MenuView.displayLine(">> Enter 10 digit Registration Number of Car (Format : AA01KK8020) : ");
			String registrationNumber=scan.next().trim();

			MenuView.displayLine("<< Color options >>\n");
			for(Entry<Integer, String> set : colorMap.entrySet())
			{
				System.out.println(" "+set.getKey()+" - "+ set.getValue()+"\n");
				//MenuView.displayLine(set.getKey()+" - "+ set.getValue()+"\n");
			}
			MenuView.displayLine(">> Choose number from the color options  : ");
			int colorChoice=scan.nextInt();
			
			ParkingSpot parkingSpot=null;
			if(registrationNumber!=null && !registrationNumber.equals("") && registrationNumber.length()==10 && colorChoice<=colorMap.size())
			{	
				parkingSpot=parkingLotInterface.parkNewCarInParkingLot(registrationNumber,colorMap.get(colorChoice));
				if(parkingSpot!=null)
				{
					MenuView.displayLine("!!! Car Parked Successfully !!!\n");
					MenuView.displayLine("!!! Car Parked with Ticket Number  : "+parkingSpot.getTicketNumber()+" !!!\n");
					MenuView.displayLine("!!! Car Parked at Spot ID Number : "+parkingSpot.getId()+" !!!\n");
				}else
				{
					MenuView.displayLine("!!! No Parking Spot is available to Park !!!\n");
				}

			}else 
				MenuView.displayLine("!!! Invalid Inputs : Please try Again !!!\n");
			

		}catch(ServiceClassException exception)
		{
			System.out.println(exception.getMessage());
		}

	}

		public void departCarFromParkingLot()
		{
			try
			{
				MenuView.displayLine(">> Enter Ticket Number of Car : ");
				String ticketNumberStr=scan.next();
				MenuView.displayLine(">> Enter Spot Id : ");
				String parkingIdStr=scan.next();

				if(isNumeric(ticketNumberStr,"LONG") && isNumeric(parkingIdStr,"INT"))
				{
				    long ticketNumber=Long.parseLong(ticketNumberStr);
				    int parkingId=Integer.parseInt(parkingIdStr);

					boolean result=false;
					if(ticketNumber>0 && parkingId>0)
					{	
						result=parkingLotInterface.departCarFromParkingLot(parkingId,ticketNumber);

						if(result==true)
						{
							MenuView.displayLine("!!! Car is being departed.   !!!\n");
							MenuView.displayLine("!!! Thank You and Have a safe journey ahead !!!\n");
						}else
						{
							MenuView.displayLine("!!! No Such Records found !!!\n");
						}

					}else
						MenuView.displayLine("!!! Invalid Inputs : Please try Again !!!\n");
					
				}

			}catch(ServiceClassException exception)
			{
				System.out.println(exception.getMessage());
			}
		}

		public void getRegistrationNumbersBasedOnColor()
		{
			try
			{
				MenuView.displayLine("<< Color Options >>\n");
				for(Entry<Integer, String> set : colorMap.entrySet())
				{
					System.out.println(" "+ set.getKey()+" - "+ set.getValue()+"\n");
					//MenuView.displayLine (set.getKey()+" - "+ set.getValue()+"\n");
				}
				MenuView.displayLine(">> Choose number from the color options  : ");
				String colorChoiceStr=scan.next();

				List<String> regNoList=null;
				if(isNumeric(colorChoiceStr,"INT"))
				 	{
				 		int colorChoice=Integer.parseInt(colorChoiceStr);
				 		if(colorChoice<=colorMap.size())
				 		{
					 		regNoList=parkingLotInterface.getRegistrationNumbersBasedOnColor(colorMap.get(colorChoice));
					 		if(regNoList!=null && regNoList.size()>0)
							{
								MenuView.displayLine("!!! Registration Number with Car Color "+colorMap.get(colorChoice)+" !!!\n");
								int count=0;
								for(String reg:regNoList)
								{
									MenuView.displayLine((++count) + " : "+reg+ "\n");
								}
							}else
							{
								MenuView.displayLine("!!! No Registration Number(s) with Car Color "+colorMap.get(colorChoice)+" !!!\n");
							}

						}


				 	}else
						MenuView.displayLine("!!! Invalid Inputs : Please try Again !!!\n");

				

			}catch(ServiceClassException exception)
			{
				System.out.println(exception.getMessage());
			}

		}

		public void getTicketNumberBasedOnRegistrationNumber()
		{
			try
			{
				MenuView.displayLine(">> Enter 10 digit Registration Number of Car (Format : AA01KK8020) : ");
				String registrationNumber=scan.next().trim();

				long ticketNumber=0;
				if(registrationNumber!=null && !(registrationNumber.equals("")) && registrationNumber.length()==10)
				{	
					ticketNumber=parkingLotInterface.getTicketNumberBasedOnRegistrationNumber(registrationNumber);
					if(ticketNumber>0)
						MenuView.displayLine("Ticket Number for Registraion Number "+registrationNumber+" is "+ ticketNumber+"\n");
					else 
						MenuView.displayLine("!!! No Ticket Number with Registration Number : "+registrationNumber+" !!!\n");
				}else 
					MenuView.displayLine("!!! Invalid Input Please try Again !!!\n");

				
			}catch(ServiceClassException exception)
			{
				System.out.println(exception.getMessage());
			}
		}

		public void getTicketNumbersBasedOnColor()
		{
			try
			{
				MenuView.displayLine("<< Color Options >>\n");
				for(Entry<Integer, String> set : colorMap.entrySet())
				{
					System.out.println(" "+ set.getKey()+" - "+ set.getValue()+"\n");
					
					//MenuView.displayLine (set.getKey()+" - "+ set.getValue()+"\n");
				}
				MenuView.displayLine(">> Choose number from the color options  : ");
				String colorChoiceStr=scan.next();

				List<Long> tickets=null;
				if(isNumeric(colorChoiceStr,"INT"))
				 	{
				 		int colorChoice=Integer.parseInt(colorChoiceStr);
				 		if(colorChoice<=colorMap.size())
				 		{
							tickets=parkingLotInterface.getTicketNumbersBasedOnColor(colorMap.get(colorChoice));

							if(tickets!=null && tickets.size()>0)
							{
								MenuView.displayLine("!!! Ticket Number(s) with Car Color "+colorMap.get(colorChoice)+" !!!\n");
								int count=0;
								for(Long ticket:tickets)
								{
									System.out.println(" "+(++count) + " Ticket Number : "+ticket+"\n");
								}
							}else
							{
								MenuView.displayLine("!!! No Registraion Number with Car Color "+colorMap.get(colorChoice)+" !!!\n");
							}
						}


				}else
					MenuView.displayLine("!!! Invalid Inputs : Please try Again !!!\n");


			}catch(ServiceClassException exception)
			{
				System.out.println(exception.getMessage());
			}
		}

		public boolean isNumeric(String str,String dtype)
		{
			int intValue;
			long longValue;
			if(str==null || str.trim().length()==0) return false;

			if(dtype.equalsIgnoreCase("INT"))
			{
				try{
					intValue=Integer.parseInt(str);
					return true;
				}catch(Exception exception){}
			}else if(dtype.equalsIgnoreCase("LONG"))
			{
				try{
					longValue=Long.parseLong(str);
					return true;
				}catch(Exception exception){}

			}
			return false;

		}

	
}