package com.park.dao;
import java.util.List;
import com.park.dto.car.Car;
import com.park.enumerations.Color;
import com.park.dto.spot.ParkingSpot;
import com.park.exceptions.DAOException;
public interface ParkingLotDAOInterface
{
	public long populateTicketNumber() throws DAOException;
	public boolean createNewParkingLot(List<ParkingSpot> parkingSpotList) throws DAOException;
	public boolean parkNewCarInParkingLot(ParkingSpot parkingSpot) throws DAOException;
	public ParkingSpot departCarFromParkingLot(ParkingSpot parkingSpot) throws DAOException;
	public boolean updateTicketCounter(long TICKET_NUMBER) throws DAOException;
	public List<ParkingSpot> loadExistingParkingLot() throws DAOException;
	
}