package com.park.services;
import java.util.List;
import com.park.dto.spot.ParkingSpot;
import com.park.enumerations.Color;
import com.park.exceptions.ServiceClassException;
public interface ParkingLotServiceInterface
{
	public boolean createNewParkingLot(int parkingSize) throws ServiceClassException;
	public ParkingSpot parkNewCarInParkingLot(String registrationNumber,String color) throws ServiceClassException;
	public boolean departCarFromParkingLot(int id,long ticketNumber) throws ServiceClassException;
	public List<String> getRegistrationNumbersBasedOnColor(String color) throws ServiceClassException;
	public long getTicketNumberBasedOnRegistrationNumber(String registrationNumber) throws ServiceClassException;
	public List<Long> getTicketNumbersBasedOnColor(String color) throws ServiceClassException;
	public boolean loadExistingParkingLot() throws ServiceClassException;
	public List<ParkingSpot> getOccupiedParkingSpotDetails() throws ServiceClassException;

	
}