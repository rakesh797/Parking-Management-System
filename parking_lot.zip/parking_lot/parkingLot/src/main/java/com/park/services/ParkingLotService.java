package com.park.services;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import com.park.heap.Node;
import com.park.dto.car.Car;
import com.park.enumerations.Color;
import com.park.heap.MinHeap;
import com.park.dto.spot.ParkingSpot;
import com.park.exceptions.ServiceClassException;
import com.park.dao.ParkingLotDAOInterface;
import com.park.dao.ParkingLotDAO;
import com.park.exceptions.DAOException;
import com.park.exceptions.ServiceClassException;

public class ParkingLotService implements ParkingLotServiceInterface
{
	public static int PARKING_SIZE=0;
	public static long TICKET_NUMBER=0;
	private Map<Integer,ParkingSpot> parkingSpotMap=new HashMap<>();
	private ParkingLotDAOInterface parkingLotDAOInterface=new ParkingLotDAO();
	private MinHeap minHeap=new MinHeap();
	private Color COLOR;

	public ParkingLotService()
	{
		TICKET_NUMBER=populateTicketNumber();
	}

	public long populateTicketNumber() 
	{
		long ticketNumber=0;
		try{
		ticketNumber=parkingLotDAOInterface.populateTicketNumber();
		}catch(DAOException daoException)
		{
			System.out.println(daoException);
			//throw new ServiceClassException("ServiceClassException :: populateTicketNumber : ",daoException);
		}
		return ticketNumber;
	}

	public boolean createNewParkingLot(int parkingSize) throws ServiceClassException
	{
		//System.out.println("Info: Service createNewParkingLot start");
		boolean result=false;
		try{
			List<ParkingSpot> parkingLotList=new ArrayList<>();
			if(parkingSize>0) 
			{
				PARKING_SIZE=parkingSize;
				int distance=0;
				for(int id=1;id<=parkingSize;id++)
				{
					Car car=new Car();
			 		ParkingSpot parkingSpot=new ParkingSpot(id,++distance,0,car,0);
			 		parkingLotList.add(parkingSpot);
			 		Node node=new Node(id,distance);
			 		minHeap.insert(node);					

				}
				result=parkingLotDAOInterface.createNewParkingLot(parkingLotList);
				if(result==false) minHeap=new MinHeap();

			}
			//System.out.println("Info: Service createNewParkingLot ends");
		}catch(DAOException daoException){
			throw new ServiceClassException("ServiceClassException :: createNewParkingLot : ",daoException);
		}
		return result;
	}


	public ParkingSpot parkNewCarInParkingLot(String registrationNumber,String color) throws ServiceClassException
	{
		ParkingSpot parkingSpot=null;
		try{
			if(parkingSpotMap.size()<PARKING_SIZE && !(registrationNumber.equals("")) && !(color.equals("")))
			{
				Node node=this.getNearestParkingSpot();
				System.out.println(node.getId());
				if(node!=null)
				{
					parkingSpot=new ParkingSpot();
					parkingSpot.setTicketNumber(++TICKET_NUMBER);
					parkingSpot.setId(node.getId());
					parkingSpot.setSpotDistance(node.getDistance());
					parkingSpot.setStatus(1);
					Car car=new Car(registrationNumber,color);
					parkingSpot.setCar(car);
					boolean result=parkingLotDAOInterface.parkNewCarInParkingLot(parkingSpot);
					if(result==true)
					{
						result=parkingLotDAOInterface.updateTicketCounter(TICKET_NUMBER);
						parkingSpotMap.put(parkingSpot.getId(),parkingSpot);
					}else
					{
						parkingSpot=null;
					}

			    }
			}
		}catch(DAOException daoException){
			throw new ServiceClassException("ServiceClassException :: parkNewCarInParkingLot : ",daoException);
		}

		return parkingSpot;

	}

	public Node getNearestParkingSpot() throws ServiceClassException
	{
		Node node=null;
		try
		{
			if(!minHeap.isEmpty())
			{
				node=minHeap.extractMin();
			}
		}catch(Exception exception)
		{
			throw new ServiceClassException("ServiceClassException :: getNearestParkingSpot : ",exception);
		}
		return node;
	}


	public boolean departCarFromParkingLot(int parkingId,long ticketNumber) throws ServiceClassException
	{

		boolean result=false;

		try{
			ParkingSpot parkingSpotExist=parkingSpotMap.get(parkingId);

			if(parkingSpotExist!=null && parkingSpotExist.getId()==parkingId && parkingSpotExist.getTicketNumber()==ticketNumber)
			{
				Car car=new Car();
				ParkingSpot parkingSpot=new ParkingSpot(parkingId,0,ticketNumber,car,0);
				ParkingSpot ps=parkingLotDAOInterface.departCarFromParkingLot(parkingSpot);
				Node node=new Node(ps.getId(),ps.getSpotDistance());
				minHeap.insert(node);
				parkingSpotMap.remove(parkingSpot.getId());
				result=true;
			}
		}catch(Exception exception){
			exception.printStackTrace();
			throw new ServiceClassException("ServiceClassException :: departCarFromParkingLot : ",exception);
		}

		return result;

	}


	public List<String> getRegistrationNumbersBasedOnColor(String color) throws ServiceClassException
	{
		List<String> list=null;
		if(!color.trim().equals(""))
		{
			try{
				list=new ArrayList<String>();
				for(ParkingSpot ps: parkingSpotMap.values())
				{
						if(ps.getCar().getColor().equalsIgnoreCase(color))
						{
							list.add(ps.getCar().getRegistrationNumber());

						}

				}

			}catch(Exception exception)
			{
				throw new ServiceClassException("ServiceClassException :: getRegistrationNumberBasedOnColor : ",exception);
			}
		}
		return list;
	}

	public long getTicketNumberBasedOnRegistrationNumber(String registrationNumber) throws ServiceClassException
	{
		long ticketNumber=0;
		if(!(registrationNumber.trim().equals("")))
		{
			
			try{
				for(ParkingSpot ps: parkingSpotMap.values())
				{
					if(ps.getCar().getRegistrationNumber().trim().equalsIgnoreCase(registrationNumber.trim()))
					{
						ticketNumber=ps.getTicketNumber();
						break;

					}

				}
			}catch(Exception exception)
			{
				throw new ServiceClassException("ServiceClassException :: getTicketNumberBasedOnRegistrationNumber : ",exception);
			}
		}
		return ticketNumber;

	}

	public List<Long> getTicketNumbersBasedOnColor(String color) throws ServiceClassException
	{

		List<Long> list=null;
		if(!color.trim().equals(""))
		{
			try{
				list=new ArrayList<Long>();
				for(ParkingSpot ps: parkingSpotMap.values())
				{
					if(ps.getCar().getColor().equalsIgnoreCase(color))
					{
						list.add(ps.getTicketNumber());

					}

				}

			}catch(Exception exception)
			{
				throw new ServiceClassException("ServiceClassException :: getTicketNumberBasedOnColor : ",exception);
			}
		}
		return list;

	}

	public boolean loadExistingParkingLot() throws ServiceClassException
	{
		boolean result=false;
		List<ParkingSpot> parkingDetails=null;
		try{
			parkingDetails=parkingLotDAOInterface.loadExistingParkingLot();
			if(parkingDetails.size()>0)
			{
				PARKING_SIZE=parkingDetails.size();
				for(ParkingSpot ps: parkingDetails)
				{
					if(ps.getTicketNumber()==0)
					{
						Node node=new Node(ps.getId(),ps.getSpotDistance());
						minHeap.insert(node);
					}else
					{
						parkingSpotMap.put(ps.getId(),ps);
					}
				}
				result=true;
			}

		}catch(Exception exception)
		{
			exception.printStackTrace();
			throw new ServiceClassException("ServiceClassException :: loadExistingParkingLot() : ",exception);
		}
		return result;
	}

	public List<ParkingSpot> getOccupiedParkingSpotDetails() throws ServiceClassException
	{

		List<ParkingSpot> parkingDetails=null;
		try
		{
			parkingDetails= new ArrayList<ParkingSpot>(parkingSpotMap.values());
		}catch(Exception exception)
		{
			throw new ServiceClassException("ServiceClassException :: loadExistingParkingLot() : ",exception);
		}
		return parkingDetails;

	}

}