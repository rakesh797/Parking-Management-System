package com.park.view;

public class MenuView
{
	public static String leftMargin=" %-15s";

	public static void displayParkingLotHeading(){
		menuBorder("=",50,"PARKING MANAGEMENT SYSTEM");
	}

	public static void displayNewParkingLotHeading() 
	{
		menuBorder("-",50,"\tMAIN MENU >> New Parking Lot");
	}

	public static void displayMainMenu()
	{
		menuBorder("-",50,"\tMAIN MENU");
		displayLine("Press 1 :: To Design New Parking Lot\n");
		displayLine("Press 2 :: To Load Previous Parking Lot\n");
		displayLine("Press 0 :: To Exit\n");
		menuEndingBorder("_",50);
	}

	public static void loadQueryMenu()
	{
		menuBorder("-",50,"\tMAIN MENU >> Query Operations");
		displayLine("Press 1 :: Park a new car in Parking Lot\n");
		displayLine("Press 2 :: Depart a car from Parking Lot\n");
		displayLine("Press 3 :: Print Registration Number(s) based on car color\n");
		displayLine("Press 4 :: Print Tickets Number(s) based on Registration Number\n");
		displayLine("Press 5 :: Print Ticket Number(s) based on car color\n");
		displayLine("Press 0 :: Previous Menu\n");
		menuEndingBorder("_",50);
	}

	public static void menuBorder(String borderString,int count,String heading)
	{
		System.out.println(borderString.repeat(count));
		System.out.println("\t"+heading);
		System.out.println(borderString.repeat(count));

	}

	public static void menuEndingBorder(String str,int count)
	{
		System.out.println(str.repeat(count));
	}

	public static void displayLine(String str)
	{
		System.out.format(leftMargin,str);
	}
}