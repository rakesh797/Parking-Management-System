package com.park.dao;
import java.util.List;
import java.util.ArrayList;
import java.io.PrintWriter;
import java.io.File;
import java.io.RandomAccessFile;
import com.park.dto.car.Car;
import com.park.enumerations.Color;
import com.park.dto.spot.ParkingSpot;
import com.park.exceptions.DAOException;
public class ParkingLotDAO implements ParkingLotDAOInterface
{
	private int id;
	private int spotDistance;
	private int status;
	File dir=new File("./resources");
	public static final String FILE_NAME_STATUS="ParkingReport.csv";
	public static final String TICKET_NUMBER_COUNTER="TicketCounter.txt";

	public long populateTicketNumber() throws DAOException
	{
		//System.out.println("Info : DAO populateTicketNumber start");
		long ticketNumber=0;
		try{
			File file=new File(dir,TICKET_NUMBER_COUNTER);
			RandomAccessFile raf=null;
			if(!file.exists())
			{
				file.createNewFile();
				raf=new RandomAccessFile(file,"rw");
				raf.writeBytes(String.valueOf(ticketNumber));
			}else
			{
				raf=new RandomAccessFile(file,"rw");
				while(raf.getFilePointer()<raf.length())
				{
					String line=raf.readLine();
					if(line!=null && line.length()>0) ticketNumber=Long.parseLong(line);

				}
			}
			raf.close();
		//System.out.println("Info : DAO populateTicketNumber ends");
		}catch(Exception exception)
		{
		
			throw new DAOException("ParkingLotDAOInterface :: populate Ticket Number : ",exception);
		}
		return ticketNumber;
	}

	public void csvWriter(StringBuilder sb) throws DAOException
	{

	File file=new File(dir,FILE_NAME_STATUS);
    try (PrintWriter writer = new PrintWriter(file)) {

      writer.write(sb.toString());

    } catch (Exception exception) {
      throw new DAOException("ParkingLotDAOInterface :: csvWriter : ",exception);
    }

  }

	public boolean updateTicketCounter(long TICKET_NUMBER) throws DAOException
	{
		boolean result=false;
		try{

			File file=new File(dir,TICKET_NUMBER_COUNTER);
			RandomAccessFile raf=null;
			if(!file.exists())
			{
				file.createNewFile();
				raf=new RandomAccessFile(file,"rw");
				raf.writeBytes(String.valueOf(TICKET_NUMBER));
			}else
			{
				raf=new RandomAccessFile(file,"rw");
				raf.seek(0);
				raf.writeBytes(String.valueOf(TICKET_NUMBER));
			}
			raf.close();
			result=true;

		}catch(Exception exception)
		{
			throw new DAOException("ParkingLotDAOInterface :: updateTicketCounter : ",exception);
		}
		return result;

	}


	public boolean createNewParkingLot(List<ParkingSpot> parkingSpotList) throws DAOException
	{
		//System.out.println("Info : DAO createNewParkingLot start");
		boolean result=false;
		try{
			File file=new File(dir,FILE_NAME_STATUS);
			if(file.exists()) file.delete();
			StringBuilder sb=new StringBuilder();
			sb.append("Id, Ticket Number, Distance, Status, Registration Number, Color\n");


			for(ParkingSpot ps:parkingSpotList)
			{
				sb.append(ps.getId()+", "+ps.getTicketNumber()+", "+
				ps.getSpotDistance()+", "+ps.getStatus()+", "+ps.getCar().getRegistrationNumber()
				+", "+"NA");
				sb.append("\n");
			}
			csvWriter(sb);
			result=true;
			//System.out.println("Info : DAO createNewParkingLot ends "+file.getAbsolutePath());
		}catch(Exception exception)
		{
			throw new DAOException("ParkingLotDAOInterface :: createNewParkingLot : ",exception);
		}
		return result;
	}


	public boolean parkNewCarInParkingLot(ParkingSpot ps) throws DAOException
	{
		boolean result=false;
		try{
			
			File file=new File(dir,FILE_NAME_STATUS);
			File fileTemp=new File(dir,"Temp.csv");
			if(file.exists())
			{
				RandomAccessFile raf=new RandomAccessFile(file,"rw");
				RandomAccessFile rafTemp=new RandomAccessFile(fileTemp,"rw");

				String header="";
				
				while(raf.getFilePointer()<raf.length())
				{
					if(header.equals(""))
					{
						header=raf.readLine();
						rafTemp.writeBytes(header);
					}
					else
					{
						String line=raf.readLine();
						String []array=line.trim().split(",");

						if(Integer.valueOf(array[0].trim())==ps.getId())
						{
						
							StringBuilder sb=new StringBuilder();
							sb.append(ps.getId()+", "+ps.getTicketNumber()+", "+
							ps.getSpotDistance()+", "+ps.getStatus()+", "+ps.getCar().getRegistrationNumber()
							+", "+ps.getCar().getColor());
							rafTemp.writeBytes(sb.toString());
							

						}
						else
						{
							rafTemp.writeBytes(line);

						}
						
					}
					rafTemp.writeBytes(System.lineSeparator());

					
				}

                raf.seek(0);
                rafTemp.seek(0);

                int i=0;
                while (rafTemp.getFilePointer()<rafTemp.length()) {
                	//System.out.println(++i);
                    raf.writeBytes(rafTemp.readLine());
                    raf.writeBytes(System.lineSeparator());
                }

                raf.setLength(rafTemp.length());
                raf.close();
                raf.close();
 
                fileTemp.delete();

			result=true;
			}else{
				throw new DAOException("Not able to Park the car.");
			}


		}catch(Exception exception)
		{
			exception.printStackTrace();
			throw new DAOException("ParkingLotDAOInterface :: ",exception);
		}

		return result;

	}


	public ParkingSpot departCarFromParkingLot(ParkingSpot ps) throws DAOException
	{
		ParkingSpot parkingSpot=null;
		try{
			parkingSpot=new ParkingSpot();
			File file=new File(dir,FILE_NAME_STATUS);
			File fileTemp=new File(dir,"Temp.csv");
			if(file.exists())
			{
				RandomAccessFile raf=new RandomAccessFile(file,"rw");
				RandomAccessFile rafTemp=new RandomAccessFile(fileTemp,"rw");

				String header="";
				
				while(raf.getFilePointer()<raf.length())
				{
					if(header.equals(""))
					{
						header=raf.readLine();
						rafTemp.writeBytes(header);
					}
					else
					{
						String line=raf.readLine();
						String []array=line.trim().split(",");

						if(Integer.valueOf(array[0].trim())==ps.getId() && Long.parseLong(array[1].trim())==ps.getTicketNumber())
						{
						
							StringBuilder sb=new StringBuilder();

							sb.append(ps.getId()+", "+0+", "+
							array[2].trim()+", "+ps.getStatus()+", "+ps.getCar().getRegistrationNumber()
							+", "+"NA");
							rafTemp.writeBytes(sb.toString());
							parkingSpot.setId(ps.getId());
							parkingSpot.setSpotDistance(Integer.parseInt(array[2].trim()));
							parkingSpot.setTicketNumber(ps.getTicketNumber());
							parkingSpot.setStatus(0);
							parkingSpot.setCar(ps.getCar());

						}
						else
						{
							rafTemp.writeBytes(line);

						}
						
					}
					rafTemp.writeBytes(System.lineSeparator());

					
				}

                raf.seek(0);
                rafTemp.seek(0);

                int i=0;
                while (rafTemp.getFilePointer()<rafTemp.length()) {
                    raf.writeBytes(rafTemp.readLine());
                    raf.writeBytes(System.lineSeparator());
                }

                raf.setLength(rafTemp.length());
                raf.close();
                raf.close();
 
                fileTemp.delete();
                }else{
				throw new DAOException("Not able to Park the car.");
			}


		}catch(Exception exception)
		{
			throw new DAOException("ParkingLotDAOInterface :: ",exception);
		}
		return parkingSpot;
	}



	public List<ParkingSpot> loadExistingParkingLot() throws DAOException
	{
	
		List<ParkingSpot> parkingDetails=null;
		try{
			parkingDetails=new ArrayList<>();
			ParkingSpot parkingSpot=null;
			File file=new File(dir,FILE_NAME_STATUS);
			if(file.exists())
			{
				RandomAccessFile raf=new RandomAccessFile(file,"rw");
				String header="";
				
				while(raf.getFilePointer()<raf.length())
				{
					if(header.equals(""))
					{
						header=raf.readLine();
					}
					else
					{
						String line=raf.readLine();
						String []array=line.trim().split(",");
						parkingSpot=new ParkingSpot();
						parkingSpot.setId(Integer.parseInt(array[0].trim()));
						parkingSpot.setTicketNumber(Long.parseLong(array[1].trim()));
						parkingSpot.setSpotDistance(Integer.parseInt(array[2].trim()));
						parkingSpot.setStatus(Integer.parseInt(array[3].trim()));
						Car car=new Car(array[4].trim(),array[5].trim());
						parkingSpot.setCar(car);
						parkingDetails.add(parkingSpot);
					}
					
				}
				raf.close();
			}

		
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw new DAOException("ParkingLotDAOInterface :: ",exception);
		}
		return parkingDetails;

	}

}